const ModalCloseBtn = document.querySelector('.modal__close');
const body = document.querySelector('body');